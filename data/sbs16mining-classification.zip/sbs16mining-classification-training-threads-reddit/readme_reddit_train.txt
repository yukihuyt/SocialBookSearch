There is one subdirectory here:
- training/ contains opening posts with category label (248 threads)

* Each thread is one xml file. 
* All posts/responses except the opening post have been removed from the file.
* The threads that can be used for training have their category label in the xml:
	<category>books</category>
	<category>suggestmeabook</category>
* the threads in the 'books' category are the negative example, the threads in the 'suggestmeabook' category are the positive examples.

Submission format for the classification task:
threadid label
for each of the threads in the test set, in which label={1,0}, 
1 meaning “the opening post of this thread is a book search request” and 
0 meaning “the opening post of this thread is not a book search request”.
